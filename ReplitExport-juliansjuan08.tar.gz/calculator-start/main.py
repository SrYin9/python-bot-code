from replit import clear

from art import logo

print(logo)

def add(n1, n2):
  answer = n1 + n2
  return answer

def subtract(n1, n2):
  answer = n1 - n2
  return answer

def multiply(n1, n2):
  answer = n1 * n2
  return answer

def divide(n1, n2):
  answer = n1 // n2
  return answer

first_number = float(input("what is your first number? "))

def calc(n1, n2):
  func = str(input("what function do you want applied to it '+ - * /'? "))
  second_number = float(input("what is your second number? "))
  answer = 0
  if func == "+":
    answer += add(first_number, second_number)

  if func == "-":
    answer += subtract(first_number, second_number)

  if func == "*":
    answer += multiply(first_number, second_number)

  if func == "/":
    answer += divide(first_number, second_number)

  print(answer)

  keep_calc = input("do you want to keep on calculating? ")
  if keep_calc == "yes":
    same_number = input("do you want to use the same number? ")
    if same_number == "yes":
      calc(n1 = answer, n2 = other_number)

calc(first_number, second_number)