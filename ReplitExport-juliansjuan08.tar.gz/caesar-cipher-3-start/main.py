alphabet = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']

direction = input("Type 'encode' to encrypt, type 'decode' to decrypt:\n")
text = input("Type your message:\n").lower()
shift = int(input("Type the shift number:\n"))

#TODO-1: Combine the encrypt() and decrypt() functions into a single function called caesar(). 

def caeser(plain_text, shift_amount, code):
  output_text = ""
  for letter in plain_text:
    position = alphabet.index(letter)
    if code == "encode":
      new_position = position + shift_amount
    elif code == "decode":
      new_position = position - shift_amount
    output_text += alphabet[new_position]
  print(f"The decoded text is {output_text}")

caeser(plain_text=text, shift_amount=shift, code=direction)