from game_data import data

import random



def random_person():
  A = random.choice(data)
  data.remove(A)
  print(f"{A['name']}, {A['description']}, {A['country']}")
  A_follower = A["follower_count"]
  return A_follower

AMOUNT_OF_CORRECTS = 0

def play():
  global AMOUNT_OF_CORRECTS

  A = random.choice(data)
  data.remove(A)
  print(f"{A['name']}, {A['description']}, {A['country']}")
  A_follower = A["follower_count"]
  print(A_follower)

  while len(data) > 0:
    B = random.choice(data)
    data.remove(B)
    print(f"{B['name']}, {B['description']}, {B['country']}")
    B_follower = B["follower_count"]
    print(B_follower)
  
    guess = input("higher or lower ")
    if guess == "higher" and A_follower < B_follower:
      AMOUNT_OF_CORRECTS += 1
      print("Correct!")
      A = B 
      A_follower = B_follower
    elif guess == "higher" and A_follower > B_follower:
      print("wrong")
    elif guess == "lower" and A_follower > B_follower:
      AMOUNT_OF_CORRECTS += 1
      print("Correct!")
      A = B 
      A_follower = B_follower
    elif guess == "higher" and A_follower < B_follower:
      print("wrong")    

play()

def junk():
  A = random.choice(data)
  data.remove(A)
  print(f"{A['name']}, {A['description']}, {A['country']}")
  A_follower = A["follower_count"]
  print(A_follower)

  B = random.choice(data)
  data.remove(B)
  print(f"{B['name']}, {B['description']}, {B['country']}")
  B_follower = B["follower_count"]
  print(B_follower)