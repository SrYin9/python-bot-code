from data import question_data
import random

points = 0

def get_a_question():
  
  global points
  question = random.choice(question_data)
  text = question['text']
  answer = question['answer'].lower()
  
  player_answer = input(text).lower()
  question_data.remove(question)
  if player_answer == answer:
    points += 1

get_a_question()
get_a_question()
get_a_question()
get_a_question()

print(f'you got {points}/4 points')