from replit import clear
#HINT: You can call clear() to clear the output in the console.

name = input("name ")
bid = int(input("bid "))

def auction(name, bid):
  
