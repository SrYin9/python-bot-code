print("Welcome to the rollercoaster!")
height = int(input("What is your height in cm? "))

bill = 0

if height >= 120:
  age = (int(input("What is your age? ")))
  if age < 12:
    bill = 5
    print("Please pay $5.")
  elif age < 18:
    bill = 7
    print("Please pay $7.")
  elif age >= 45 and age <= 55:
    bill = 0
    print("Your ticket is free!")
  else:
    bill = 12
    print("Please pay $12.")
  photo = input("Do you want a photo? type: Y or N. ")
  if photo == "Y":
    print(f"That will be $3. \nYour new total is ${int(bill)+3}.")
  else:
    print(f"Your total is ${bill}.")
else:
  print("you can't ride it")