name = input("What is your name?")
print("Hello " + name)
name = input("What is your name?")
print("Hello " + name)