from game_data import data
import random

# Function to get a random person from data
def get_random_person():
    return random.choice(data)

# Function to play the game
def play():
    amount_of_corrects = 0  # Initialize correct count for this play session

    A = get_random_person()
    data.remove(A)
    print(f"{A['name']}, {A['description']}, {A['country']}")
    A_follower = A["follower_count"]
    print(A_follower)

    while len(data) > 0:  # Continue while there are items left in data
        B = get_random_person()
        data.remove(B)
        print(f"{B['name']}, {B['description']}, {B['country']}")
        B_follower = B["follower_count"]
        print(B_follower)

        guess = input("Higher or lower? ").lower()

        if (guess == "higher" and A_follower < B_follower) or (guess == "lower" and A_follower > B_follower):
            amount_of_corrects += 1
            print("Correct!")
            A = B  # Make B the new A
            A_follower = B_follower  # Update A_follower to B_follower
        else:
            print("Wrong!")
            break  # End the game if the guess is wrong

    print(f"Game over! You got {amount_of_corrects} correct answers.")

# Start the game
play()
