def my_func():
  print("hello")
  print("bye")

my_func()