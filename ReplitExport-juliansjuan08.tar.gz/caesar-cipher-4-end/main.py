from art import logo
import random

deck_of_cards = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"] * 4

def deal_initial_hands(deck):
    return [deck.pop(random.randint(0, len(deck) - 1)) for _ in range(2)], [deck.pop(random.randint(0, len(deck) - 1)) for _ in range(2)]
    print(deal_initial_hands(deck))

def calculate_hand_value(cards):
    total_value = 0
    num_aces = cards.count('A')
    for card in cards:
        if card in ['J', 'Q', 'K']:
            total_value += 10
        elif card == 'A':
            total_value += 11
        else:
            total_value += int(card)
    while total_value > 21 and num_aces:
        total_value -= 10
        num_aces -= 1
    return total_value
    print(calculate_hand_value(cards))

def draw_card(deck):
    return deck.pop(random.randint(0, len(deck) - 1))

def player_turn(deck, hand):
    while input("Another card? (y/n) ") == "y":
        hand.append(draw_card(deck))
        hand_value = calculate_hand_value(hand)
        print(f"Your cards: {hand}, current hand value: {hand_value}")
        if hand_value > 21:
            print("Bust!")
            return hand_value
        elif hand_value == 21:
            print("21! Nice!")
            return hand_value
    return calculate_hand_value(hand)

def dealer_turn(deck, hand):
    hand_value = calculate_hand_value(hand)
    while hand_value < 17:
        hand.append(draw_card(deck))
        hand_value = calculate_hand_value(hand)
    return hand_value

def main():
    print(logo)

    deck = deck_of_cards.copy()
    player_hand, dealer_hand = deal_initial_hands(deck)

    print(f"Your cards: {player_hand}")
    print(f"Dealer's first card: {dealer_hand[0]}")

    player_value = player_turn(deck, player_hand)
    if player_value <= 21:
        dealer_value = dealer_turn(deck, dealer_hand)
        print(f"Dealer's cards: {dealer_hand}, dealer's hand value: {dealer_value}")

        if dealer_value > 21 or player_value > dealer_value:
            print("You win!")
        elif player_value < dealer_value:
            print("Dealer wins.")
        else:
            print("It's a tie!")
    else:
        print("Dealer wins.")

if __name__ == "__main__":
    main()