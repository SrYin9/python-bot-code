programming_dictionary = {
  "Bug": "An error in a program that prevents the program from running as expected.", 
  "Function": "A piece of code that you can easily call over and over again.",
}

programming_dictionary["Loop"] = "ibsusihbuniunNFINIUNFIUNIUSDNIUN srugoinv"

programming_dictionary["Bug"] = "iunsd"

for key in programming_dictionary:
  print(f"{key} : {programming_dictionary[key]}")

