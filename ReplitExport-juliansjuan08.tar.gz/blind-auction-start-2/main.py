from replit import clear
#HINT: You can call clear() to clear the output in the console.