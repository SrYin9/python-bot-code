import
random_float = random.random()
print(random_float)