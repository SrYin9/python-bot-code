import random

# Function to calculate the total value of cards in hand
def calculate_hand_value(cards):
    total_value = 0
    num_aces = 0

    for card in cards:
        if card in ['J', 'Q', 'K']:
            total_value += 10
        elif card == 'A':
            num_aces += 1
            total_value += 11
        else:
            total_value += int(card)

    # Adjust Ace value from 11 to 1 if total value exceeds 21
    while total_value > 21 and num_aces > 0:
        total_value -= 10
        num_aces -= 1

    return total_value

# Function to deal a new card
def deal_card():
    cards = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A']
    return random.choice(cards)

# Function to display cards in hand
def display_cards(cards):
    return ', '.join(cards)

# Main game function
def blackjack():
    print("Welcome to Blackjack!")

    # Initialize player and dealer hands
    player_hand = []
    dealer_hand = []

    # Deal two cards to player and dealer
    player_hand.append(deal_card())
    player_hand.append(deal_card())
    dealer_hand.append(deal_card())
    dealer_hand.append(deal_card())

    # Display initial hands
    print("Your cards:", display_cards(player_hand))
    print("Dealer's cards:", display_cards(dealer_hand[0:1]), "[Hidden]")

    # Player's turn
    while True:
        player_choice = input("Do you want to hit or stand? (h/s): ").strip().lower()

        if player_choice == 'h':
            new_card = deal_card()
            player_hand.append(new_card)
            print("You drew:", new_card)
            print("Your cards:", display_cards(player_hand))

            # Check if player busts
            if calculate_hand_value(player_hand) > 21:
                print("Bust! You lose.")
                return False

        elif player_choice == 's':
            break
        else:
            print("Invalid input. Please enter 'h' or 's'.")

    # Dealer's turn
    print("\nDealer's turn...")
    print("Dealer's cards:", display_cards(dealer_hand))

    while calculate_hand_value(dealer_hand) < 17:
        new_card = deal_card()
        dealer_hand.append(new_card)
        print("Dealer drew:", new_card)
        print("Dealer's cards:", display_cards(dealer_hand))

    # Determine the winner
    player_score = calculate_hand_value(player_hand)
    dealer_score = calculate_hand_value(dealer_hand)

    print("\nYour score:", player_score)
    print("Dealer's score:", dealer_score)

    if player_score > 21:
        print("You bust! Dealer wins.")
    elif dealer_score > 21:
        print("Dealer busts! You win.")
    elif player_score > dealer_score:
        print("You win!")
    elif player_score < dealer_score:
        print("Dealer wins.")
    else:
        print("It's a tie!")

# Start the game
blackjack()
