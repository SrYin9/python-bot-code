import random

move = int(input("How many letters to move? "))

alphabet1 = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
alphabet2 = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']

ceaser_list = alphabet2

# Shift the letters
ceaser_list = alphabet2[move:] + alphabet2[:move]

print("Original Alphabet:", alphabet1)
print("Ceaser Alphabet:", ceaser_list)