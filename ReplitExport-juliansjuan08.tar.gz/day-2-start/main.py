print("welcome to the tip calculator")
bill = float(input("what was the total bill? $"))
tip = int(input("what percentage tip would you like to give? 10, 12, or 15? "))
people = int(input("how many people to split the bill? "))
tip_as_percent = tip / 100
bill_per_person = bill / people
total_tip_amount = bill_per_person * tip_as_percent
your_total_bill = bill_per_person + total_tip_amount
your_final_amount = round(your_total_bill, 2)
print(f"YO ASS B PAYING {your_final_amount})

