rock = '''
    _______
---'   ____)
      (_____)
      (_____)
      (____)
---.__(___)
'''

paper = '''
    _______
---'   ____)____
          ______)
          _______)
         _______)
---.__________)
'''

scissors = '''
    _______
---'   ____)____
          ______)
       __________)
      (____)
---.__(___)
'''

#Write your code below this line 👇
import random
players_choice = int(input("1 for rock, 2 for paper, 3 for scissors\n"))
choices = [rock, paper, scissors]
player = choices[players_choice - 1]
print(player)
print("Computer choses:")
computer = choices[random.randint(0,2)]
print(computer)
if player == computer:
  print("Tie!")
elif ((player == "rock" and computer == "scissors") or
     (player == "paper" and computer == "rock") or
     (player == "scissors" and computer == "paper")):
  print("WIN!")
else:
  print("lose, try again?")