print("Bonjour ppls wat u want ur name to be?")
print("what city did u grow up in?")
city_name = input()
print("what is the name of ur pet?")
pet_name = input()
print("ur band name is " + city_name + " " + pet_name)




#1. Create a greeting for your program.

#2. Ask the user for the city that they grew up in.

#3. Ask the user for the name of a pet.

#4. Combine the name of their city and pet and show them their band name.

#5. Make sure the input cursor shows on a new line:

# Solution: https://replit.com/@appbrewery/band-name-generator-end