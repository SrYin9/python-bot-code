def format_name(f_name, l_name):
  formated_f_name = f_name.title()
  formated_l_name = l_name.title()
  return(f"formated name: {formated_f_name} {formated_l_name}")

print(format_name("uRRR", "GAEEEEEE"))